
<?php

require_once 'vendor/autoload.php';

use Dompdf\Dompdf;
$document = new Dompdf;

$html="<h1>OLA MUNDO</h1>";

$document->loadHtml($html);

$document->setPaper("A4", "landscape");
$document->render();

$document->stream("relatorio.pdf",  array("Attachment"=>FALSE));


